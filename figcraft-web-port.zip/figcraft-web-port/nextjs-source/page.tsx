'use client'

import { useState } from 'react'
import {
  Boxes,
  FileDown,
  Hand,
  LayoutGrid,
  Move,
  Palette,
  PenTool,
  Play,
  Smartphone,
  Zap,
  ZoomIn,
} from 'lucide-react'
import { EditorOverlay } from '@/components/editor-overlay'

const GESTURES = [
  {
    icon: Hand,
    title: 'One finger',
    body: 'Tap to select, drag to move shapes and drag on empty canvas to marquee-select — just like a mouse.',
  },
  {
    icon: ZoomIn,
    title: 'Pinch to zoom',
    body: 'Two fingers pinch or spread zooms the canvas smoothly, mapped to the engine\u2019s native zoom input.',
  },
  {
    icon: Move,
    title: 'Two-finger pan',
    body: 'Slide two fingers to pan the canvas. The gesture adapter drives the engine\u2019s middle-button pan path.',
  },
  {
    icon: Smartphone,
    title: 'Built for small screens',
    body: 'The editor fills the viewport edge-to-edge with browser zoom and rubber-band scrolling locked out.',
  },
]

const FEATURES = [
  {
    icon: LayoutGrid,
    title: 'Frames & auto layout',
    body: 'Responsive layouts with hug/fill sizing, nested containers and padding controls that reflow as you edit.',
  },
  {
    icon: Boxes,
    title: 'Components & variants',
    body: 'Reusable main components with instances, overrides and variant switching across your whole document.',
  },
  {
    icon: PenTool,
    title: 'Vector networks',
    body: 'A full vector editor: pen tool, boolean operations, corner radius, width profiles and path editing.',
  },
  {
    icon: Palette,
    title: 'Styles & variables',
    body: 'Shared colour, text and effect styles plus variables with modes — one set of tokens, light and dark.',
  },
  {
    icon: Play,
    title: 'Prototyping',
    body: 'Wire flows with interactions, then present them right in the browser with responsive previews.',
  },
  {
    icon: FileDown,
    title: 'Figma import',
    body: 'Open .fig files directly — the engine reads Figma\u2019s Kiwi-serialized document format natively.',
  },
]

const GALLERY = [
  {
    src: '/screenshots/shot-1-hero.png',
    alt: 'FigCraft dark theme editing the Ridgeline hiking app with auto layout layers and variable-bound fills',
    caption: 'Auto layout screens with theme variable modes',
  },
  {
    src: '/screenshots/shot-2-components.png',
    alt: 'Component panel showing variants and instances in FigCraft',
    caption: 'Components & variants at work',
  },
  {
    src: '/screenshots/shot-5-vector.png',
    alt: 'Vector editing with pen tool and anchor points in FigCraft',
    caption: 'Vector networks & the pen tool',
  },
  {
    src: '/screenshots/shot-6-dashboard-light.png',
    alt: 'Ridgeline studio dashboard design in light mode',
    caption: 'Dashboards built from shared styles',
  },
]

export default function Home() {
  const [editorOpen, setEditorOpen] = useState(false)

  const launch = () => setEditorOpen(true)

  return (
    <div className="flex min-h-screen flex-col bg-[#0b0e11] text-zinc-100">
      <EditorOverlay open={editorOpen} onClose={() => setEditorOpen(false)} />

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0b0e11]/85 backdrop-blur">
        <div className="mx-auto flex h-14 w-full max-w-5xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <img src="/artcraft-mark.png" alt="ArtCraft mark" className="h-7 w-7 rounded-md" />
            <span className="text-base font-semibold tracking-tight">FigCraft</span>
            <span className="rounded-full border border-[#0EA5C6]/40 bg-[#0EA5C6]/10 px-2 py-0.5 text-[11px] font-medium text-[#67d6ec]">
              web port
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-zinc-500 sm:inline">v0.8.0</span>
            <button
              onClick={launch}
              className="flex h-9 items-center gap-1.5 rounded-lg bg-[#0EA5C6] px-3.5 text-sm font-semibold text-[#05242b] transition-colors hover:bg-[#3cbddd]"
            >
              <Play className="h-3.5 w-3.5 fill-current" aria-hidden />
              Launch
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden border-b border-white/10">
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_-10%,rgba(14,165,198,0.18),transparent)]"
          />
          <div className="relative mx-auto flex w-full max-w-5xl flex-col items-center px-4 py-14 text-center sm:px-6 sm:py-20">
            <div className="flex flex-wrap items-center justify-center gap-2">
              {['Open source', '100% Rust', 'Runs offline'].map((chip) => (
                <span
                  key={chip}
                  className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-zinc-300"
                >
                  {chip}
                </span>
              ))}
            </div>
            <h1 className="mt-5 max-w-2xl text-balance text-3xl font-bold leading-tight tracking-tight sm:text-5xl sm:leading-[1.1]">
              Interface design and prototyping —{' '}
              <span className="text-[#0EA5C6]">in your browser</span>.
            </h1>
            <p className="mt-4 max-w-xl text-pretty text-sm leading-relaxed text-zinc-400 sm:text-base">
              The open-source design tool from the ArtCraft community, ported to the web as a
              WebAssembly app and tuned for touch. Frames, auto layout, components, vector
              networks, styles, variables and prototypes — all on your phone.
            </p>
            <div className="mt-7 flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
              <button
                onClick={launch}
                className="flex h-12 items-center justify-center gap-2 rounded-xl bg-[#0EA5C6] px-7 text-base font-semibold text-[#05242b] shadow-lg shadow-[#0EA5C6]/20 transition-colors hover:bg-[#3cbddd]"
              >
                <Play className="h-4 w-4 fill-current" aria-hidden />
                Launch Editor
              </button>
              <a
                href="/figcraft/index.html"
                target="_blank"
                rel="noopener"
                className="flex h-12 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-7 text-base font-medium text-zinc-100 transition-colors hover:bg-white/10"
              >
                Open standalone
                <span aria-hidden> ↗</span>
              </a>
            </div>
            <p className="mt-4 text-xs text-zinc-500">
              WebGPU with WebGL2 fallback &middot; ~7&nbsp;MB download, cached after first load
            </p>
          </div>
        </section>

        {/* Touch gestures */}
        <section className="border-b border-white/10">
          <div className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6 sm:py-16">
            <div className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-[#0EA5C6]" aria-hidden />
              <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">Made to work on mobile</h2>
            </div>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-zinc-400">
              The stock web build isn&apos;t touch-first, so this port adds a gesture adapter that
              translates multi-finger input into the engine&apos;s native mouse and zoom pathways.
            </p>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {GESTURES.map((g) => (
                <div
                  key={g.title}
                  className="rounded-xl border border-white/10 bg-white/[0.04] p-4 transition-colors hover:border-[#0EA5C6]/30"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0EA5C6]/15">
                    <g.icon className="h-4.5 w-4.5 text-[#0EA5C6]" aria-hidden />
                  </div>
                  <h3 className="mt-3 text-sm font-semibold">{g.title}</h3>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-zinc-400">{g.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Gallery */}
        <section className="border-b border-white/10">
          <div className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6 sm:py-16">
            <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">
              Built with the real engine
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-zinc-400">
              Every screen below ships as an example file in the repository and renders live in
              the editor you just launched.
            </p>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {GALLERY.map((shot) => (
                <figure
                  key={shot.src}
                  className="overflow-hidden rounded-xl border border-white/10 bg-white/[0.03]"
                >
                  <img
                    src={shot.src}
                    alt={shot.alt}
                    loading="lazy"
                    className="aspect-[16/10] w-full object-cover object-top"
                  />
                  <figcaption className="border-t border-white/10 px-4 py-2.5 text-[13px] text-zinc-400">
                    {shot.caption}
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="border-b border-white/10">
          <div className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6 sm:py-16">
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-[#0EA5C6]" aria-hidden />
              <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">
                Everything in the toolkit
              </h2>
            </div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <div
                  key={f.title}
                  className="rounded-xl border border-white/10 bg-white/[0.04] p-5 transition-colors hover:border-[#0EA5C6]/30"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0EA5C6]/15">
                    <f.icon className="h-4.5 w-4.5 text-[#0EA5C6]" aria-hidden />
                  </div>
                  <h3 className="mt-3 text-sm font-semibold">{f.title}</h3>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-zinc-400">{f.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section>
          <div className="mx-auto w-full max-w-5xl px-4 py-14 text-center sm:px-6 sm:py-20">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Ready to design?</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-zinc-400">
              Launch the editor and start a new document — it opens instantly and keeps working
              offline.
            </p>
            <button
              onClick={launch}
              className="mt-6 inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-[#0EA5C6] px-8 text-base font-semibold text-[#05242b] shadow-lg shadow-[#0EA5C6]/20 transition-colors hover:bg-[#3cbddd]"
            >
              <Play className="h-4 w-4 fill-current" aria-hidden />
              Launch FigCraft
            </button>
          </div>
        </section>
      </main>

      {/* Footer — sticks to bottom via mt-auto on the flex root */}
      <footer className="mt-auto border-t border-white/10 bg-[#0b0e11] pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
            <div className="max-w-md">
              <div className="flex items-center gap-2">
                <img src="/artcraft-mark.png" alt="" className="h-5 w-5 rounded" />
                <span className="text-sm font-semibold">FigCraft Web</span>
              </div>
              <p className="mt-2 text-xs leading-relaxed text-zinc-500">
                An unofficial mobile-first port serving the official prebuilt web release
                (v0.8.0) of <span className="text-zinc-400">storytold/figcraft</span>. FigCraft is
                a community project by ArtCraft — all engine credit goes to its contributors.
              </p>
            </div>
            <nav aria-label="Footer" className="flex flex-col gap-2 text-xs">
              <a
                href="https://github.com/storytold/figcraft"
                target="_blank"
                rel="noopener"
                className="text-zinc-400 transition-colors hover:text-[#0EA5C6]"
              >
                GitHub repository ↗
              </a>
              <a
                href="https://getartcraft.com/apps/figcraft"
                target="_blank"
                rel="noopener"
                className="text-zinc-400 transition-colors hover:text-[#0EA5C6]"
              >
                getartcraft.com ↗
              </a>
              <span className="text-zinc-500">MIT OR Apache-2.0 &middot; WASM engine unchanged</span>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  )
}

