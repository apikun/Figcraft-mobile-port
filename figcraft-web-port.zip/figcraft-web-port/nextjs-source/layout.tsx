import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FigCraft Web — Interface Design & Prototyping",
  description:
    "Open-source, collaborative interface design and prototyping built in pure Rust. Frames, auto layout, components, vector networks, styles, variables and prototypes — now running in your browser and on mobile.",
  keywords: [
    "FigCraft",
    "design tool",
    "prototyping",
    "WebAssembly",
    "Rust",
    "open source",
    "Figma alternative",
  ],
  authors: [{ name: "ArtCraft / storytold" }],
  icons: {
    icon: "/artcraft-mark.png",
  },
  manifest: "/manifest.webmanifest",
  openGraph: {
    title: "FigCraft Web — Interface Design & Prototyping",
    description:
      "The open-source design tool built in pure Rust, ported to the web. Works on mobile with touch gestures.",
    siteName: "FigCraft Web",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b0e11",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
