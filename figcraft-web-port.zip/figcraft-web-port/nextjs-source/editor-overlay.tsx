'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { ExternalLink, X } from 'lucide-react'

/**
 * Fullscreen wrapper for the FigCraft WASM editor.
 *
 * - The iframe is created the first time the editor is opened and stays
 *   mounted afterwards, so the app keeps its state when toggling back home.
 * - Loading detection polls `contentWindow.wasmBindings`, which the trunk
 *   module script sets right after the WASM finishes compiling (the
 *   TrunkApplicationStarted event can fire before a listener can attach,
 *   so polling is the reliable signal).
 */
export function EditorOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [everOpened, setEverOpened] = useState(false)
  const [loading, setLoading] = useState(true)
  const iframeRef = useRef<HTMLIFrameElement | null>(null)

  // Render-phase state adjustment (react.dev/learn/you-might-not-need-an-effect):
  // latch "has ever been opened" so the iframe mounts once and never unmounts.
  if (open && !everOpened) {
    setEverOpened(true)
  }

  useEffect(() => {
    if (!everOpened) return
    let cancelled = false
    const started = Date.now()

    const poll = window.setInterval(() => {
      if (cancelled) return
      const win = iframeRef.current?.contentWindow
      if (win && (win as unknown as { wasmBindings?: unknown }).wasmBindings) {
        window.clearInterval(poll)
        setLoading(false)
      } else if (Date.now() - started > 25000) {
        // WASM compile or GPU init is taking unusually long — reveal anyway.
        window.clearInterval(poll)
        setLoading(false)
      }
    }, 250)

    return () => {
      cancelled = true
      window.clearInterval(poll)
    }
  }, [everOpened])

  const popOut = useCallback(() => {
    window.open('/figcraft/index.html', '_blank', 'noopener')
  }, [])

  if (!everOpened) return null

  return (
    <div
      className={`fixed inset-0 z-50 bg-[#2c2c2c] ${open ? '' : 'hidden'}`}
      role="dialog"
      aria-label="FigCraft editor"
    >
      <iframe
        ref={iframeRef}
        src="/figcraft/index.html"
        title="FigCraft editor"
        className="absolute inset-0 h-full w-full border-0"
        style={{ touchAction: 'none' }}
        allow="fullscreen; clipboard-read; clipboard-write"
        allowFullScreen
      />

      {loading && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-[#2c2c2c] text-zinc-300">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-zinc-600 border-t-[#0EA5C6]" />
          <p className="text-sm font-medium">Loading FigCraft…</p>
          <p className="max-w-xs text-center text-xs text-zinc-500">
            Compiling the WebAssembly engine — the first launch takes a few seconds, and the app
            is cached for offline use afterwards.
          </p>
        </div>
      )}

      {!loading && (
        <div className="absolute bottom-4 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2 opacity-55 transition-opacity hover:opacity-100 focus-within:opacity-100 active:opacity-100">
          <button
            onClick={onClose}
            aria-label="Back to FigCraft home"
            className="flex h-11 items-center gap-1.5 rounded-full border border-white/10 bg-black/50 px-4 text-sm font-medium text-white/90 backdrop-blur transition-colors hover:bg-black/70"
          >
            <X className="h-4 w-4" aria-hidden />
            Back
          </button>
          <button
            onClick={popOut}
            aria-label="Open editor in a new tab"
            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-black/50 text-white/90 backdrop-blur transition-colors hover:bg-black/70"
          >
            <ExternalLink className="h-4 w-4" aria-hidden />
          </button>
        </div>
      )}
    </div>
  )
}
